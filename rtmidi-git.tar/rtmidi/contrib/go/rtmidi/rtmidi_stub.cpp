#include "../../../RtMidi.h"

#define RTMIDI_SOURCE_INCLUDED
#include "../../../RtMidi.cpp"
#include "../../../rtmidi_c.cpp"
